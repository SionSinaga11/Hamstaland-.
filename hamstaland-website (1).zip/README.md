# Hamstaland Website

This is a simple static website for Hamstaland - $HMLD Meme Coin.

## How to deploy on GitHub Pages

1. Create a new repository on GitHub and push this project.
2. Go to repository Settings -> Pages.
3. Choose the branch (usually main or master) and the folder (`/root` or `/docs` if you put the site files there).
4. Save and wait for GitHub to deploy your site.
5. Your site will be available at `https://<your-username>.github.io/<repository-name>/`.

## Notes
- Replace the subscription form action URL in `index.html` to your real backend or mailing list service.
- Update social media links in the header as needed.
- Replace images with your own assets if necessary.

---

Created with ❤️ by Hamstaland Team
